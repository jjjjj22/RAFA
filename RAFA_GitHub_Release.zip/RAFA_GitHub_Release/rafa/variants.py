"""Minimal architecture-adapted DBM/H2T *research examples*.

IMPORTANT: these two integrations preserve the intended RAFA feature interface,
but do NOT claim exact replication of the original DBM/H2T papers or of
historical experiment checkpoints. See docs/IMPLEMENTATION_SCOPE.md.
"""
import torch
from torch import nn
from torch.nn import functional as F
from .model import RAFAClassifier, make_backbone, RarityAwareFeatureAdapter


class CosineHead(nn.Module):
    def __init__(self,d,classes,scale=30.):
        super().__init__()
        self.weight=nn.Parameter(torch.empty(classes,d))
        nn.init.xavier_normal_(self.weight)
        self.scale=scale
    def forward(self,x):
        return self.scale * F.linear(F.normalize(x.float(),dim=-1),F.normalize(self.weight.float(),dim=-1))


class DBMVariant(RAFAClassifier):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        classes=self.classifier.out_features
        self.classifier=CosineHead(self.feature_dim,classes)


def dbm_style_loss(logits,labels,counts,max_margin=0.1,margin_tau=0.5,lambda_inst=1.):
    """Frequency + instance difficulty margin *approximation*.

    This is deliberately named dbm_style_loss, not an exact DBM author loss.
    Requires original official DBM code for strict paper-method reproduction.
    """
    freq=torch.as_tensor(counts,device=logits.device,dtype=torch.float32)
    base=(freq.min()/freq).pow(margin_tau)
    prob=logits.float().softmax(-1).gather(1,labels[:,None]).squeeze(1)
    difficulty=(1.-prob.detach())
    margin=max_margin*base[labels]*(1.+lambda_inst*difficulty)
    corrected=logits.float().clone()
    corrected.scatter_add_(1,labels[:,None],-margin[:,None])
    return F.cross_entropy(corrected,labels)


class H2TVariant(RAFAClassifier):
    """Same backbone and RAFA; optional training-only head-to-tail mix.

    Stage 1 trains the ordinary CE classifier; stage 2 freezes backbone and
    learns from source/target training feature mixtures, never test samples.
    """
    def freeze_backbone(self):
        for p in self.backbone.parameters():p.requires_grad=False
        self.backbone.eval()
    def mixed_logits(self,target_images,donor_images,rho=0.3):
        with torch.no_grad():
            target=self.backbone(target_images)
            donor=self.backbone(donor_images)
        # Feature-level convex mixing; distinct from H2T's original partial-map fusion.
        z=(1-rho)*target+rho*donor
        if self.adapter is None:return self.classifier(z),None
        z,aux=self.adapter(z,return_aux=True)
        return self.classifier(z),aux
