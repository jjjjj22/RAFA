"""CIFAR-100 official pickle and natural long-tail ImageFolder data protocols.

No public dataset images included in this repository. All class counts are
computed from training splits exclusively; validation/test are never used to
build rarity priors. A manifest freezes split identities for paired runs.
"""
from pathlib import Path
import json
import pickle
import numpy as np
import torch
from PIL import Image
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
from torchvision.transforms import InterpolationMode


def _raw_cifar(root, split):
    root = Path(root)
    if (root/'cifar-100-python').is_dir(): root = root/'cifar-100-python'
    with (root/split).open('rb') as f:
        raw = pickle.load(f, encoding='bytes')
    data = raw.get(b'data',raw.get('data'))
    labels = raw.get(b'fine_labels',raw.get('fine_labels'))
    return np.asarray(data).reshape(-1,3,32,32).transpose(0,2,3,1).copy(), np.asarray(labels,dtype=int)


def _cifar_names(root):
    root=Path(root)
    if (root/'cifar-100-python').is_dir(): root=root/'cifar-100-python'
    with (root/'meta').open('rb') as f: meta=pickle.load(f,encoding='bytes')
    names=meta.get(b'fine_label_names',meta.get('fine_label_names'))
    return [x.decode() if isinstance(x,bytes) else str(x) for x in names]


def create_cifar_manifest(root, output, imbalance_factor=100., val_fraction=0.1, seed=42):
    root=Path(root).expanduser().resolve()
    if (root/'cifar-100-python').is_dir(): root=root/'cifar-100-python'
    _, labels=_raw_cifar(root,'train')
    _, test_labels=_raw_cifar(root,'test')
    rng=np.random.default_rng(seed)
    train,val=[],[]
    for cls in range(100):
        indices=np.flatnonzero(labels==cls)
        rng.shuffle(indices)
        desired = max(1,int(len(indices)*(imbalance_factor**(-cls/99))))
        indices=indices[:desired]
        n_val=min(desired-1,max(1,round(desired*val_fraction))) if desired>1 and val_fraction>0 else 0
        val.extend((int(i),cls) for i in indices[:n_val])
        train.extend((int(i),cls) for i in indices[n_val:])
    rng.shuffle(train)
    rng.shuffle(val)
    test=[(int(i),int(y)) for i,y in enumerate(test_labels)]
    manifest={'format_version':1, 'dataset':'cifar100lt', 'root':str(root),
              'classes':_cifar_names(root), 'seed':int(seed),
              'imbalance_factor_requested':float(imbalance_factor),
              'train':train,'val':val,'test':test}
    _save_manifest(output,manifest)
    return manifest


def _scan_class_folders(root,classes):
    extensions={'.jpg','.jpeg','.png','.bmp','.webp','.tif','.tiff'}
    result=[]
    for ci,name in enumerate(classes):
        path=root/name
        for p in sorted(path.rglob('*')):
            if p.is_file() and p.suffix.lower() in extensions:
                result.append((p.relative_to(root).as_posix(),ci))
    return result


def create_folder_manifest(root, output, train_fraction=0.72, val_fraction=0.08, seed=42):
    """Supports root/class/images or root/{train,val,test}/class/images.

    Existing partitions are preserved. Otherwise per-class deterministic
    stratification is performed once and saved to JSON.
    """
    root=Path(root).expanduser().resolve()
    if train_fraction <= 0 or val_fraction <= 0 or train_fraction+val_fraction >= 1:
        raise ValueError('Need 0 < train_fraction, val_fraction and sum < 1')
    presplit=all((root/s).is_dir() for s in ('train','val','test'))
    if presplit:
        classes=sorted({d.name for s in ('train','val','test') for d in (root/s).iterdir() if d.is_dir()})
        recs={}
        for split in ('train','val','test'):
            recs[split]=[(f'{split}/{r}',c) for r,c in _scan_class_folders(root/split, classes)]
    else:
        classes=sorted(d.name for d in root.iterdir() if d.is_dir() and not d.name.startswith('.'))
        rng=np.random.default_rng(seed)
        recs={'train':[],'val':[],'test':[]}
        for ci,name in enumerate(classes):
            entries=_scan_class_folders(root,[name])
            entries=[(x,ci) for x,_ in entries]
            rng.shuffle(entries)
            n=len(entries)
            if n<3:
                raise ValueError(f'Class {name!r} has {n} images; need >=3 for train/val/test')
            n_test=max(1,int(round(n*(1-train_fraction-val_fraction))))
            n_val=max(1,int(round(n*val_fraction)))
            if n_test+n_val>=n: n_val=1;n_test=1
            recs['test'].extend(entries[:n_test])
            recs['val'].extend(entries[n_test:n_test+n_val])
            recs['train'].extend(entries[n_test+n_val:])
        for split in recs: rng.shuffle(recs[split])
    manifest={'format_version':1, 'dataset':'folder', 'root':str(root),
              'classes':classes,'seed':int(seed),'split_type':'existing' if presplit else 'stratified',
              **recs}
    _save_manifest(output,manifest)
    return manifest


def _save_manifest(path,manifest):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('w',encoding='utf-8') as f: json.dump(manifest,f,ensure_ascii=False)


def load_manifest(path, root_override=None):
    with Path(path).open(encoding='utf-8') as f: obj=json.load(f)
    if root_override: obj['root']=str(Path(root_override).expanduser().resolve())
    if obj.get('format_version')!=1: raise ValueError('Unknown split manifest version')
    classes=obj['classes']; num=len(classes)
    for s in ('train','val','test'):
        if not obj[s]: raise ValueError(f'Empty manifest split {s}')
        if any(c<0 or c>=num for _,c in obj[s]): raise ValueError(f'Invalid class index in {s}')
    ids=[(r if obj['dataset']=='folder' else ('test',r) if s=='test' else ('train',r))
         for s in ('train','val','test') for r,_ in obj[s]]
    if len(ids)!=len(set(ids)): raise ValueError('Train/val/test data leakage detected')
    return obj


def training_counts(manifest):
    c=np.bincount([j for _,j in manifest['train']],minlength=len(manifest['classes']))
    if (c<=0).any():raise ValueError('Every class needs at least 1 training example')
    return c.tolist()


def image_transforms(dataset, size=224, train=False, bcl=False):
    mean=(0.485,0.456,0.406)
    std=(0.229,0.224,0.225)
    resize=transforms.Resize((size,size),interpolation=InterpolationMode.BICUBIC)
    suffix=[transforms.ToTensor(),transforms.Normalize(mean,std)]
    if not train:
        return transforms.Compose([resize,*suffix])
    if dataset=='cifar100lt':
        if bcl:
            return transforms.Compose([transforms.RandomResizedCrop(32,scale=(.5,1.0)),
                                       transforms.RandomHorizontalFlip(),
                                       transforms.RandomApply([transforms.ColorJitter(.35,.35,.35,.12)],p=.8),
                                       transforms.RandomGrayscale(p=.2),resize,*suffix])
        return transforms.Compose([transforms.RandomCrop(32,padding=4),
                                   transforms.RandomHorizontalFlip(),resize,*suffix])
    if bcl:
        return transforms.Compose([transforms.RandomResizedCrop(size,scale=(.5,1.0)),
                                   transforms.RandomHorizontalFlip(),transforms.RandomApply(
                                   [transforms.ColorJitter(.35,.35,.35,.12)],p=.8),*suffix])
    return transforms.Compose([transforms.RandomResizedCrop(size),
                               transforms.RandomHorizontalFlip(),*suffix])


class ImageDataset(Dataset):
    def __init__(self, manifest, split, size=224, bcl=False):
        self.manifest=manifest
        self.split=split
        self.samples=manifest[split]
        self.data_type=manifest['dataset']
        self.root=Path(manifest['root'])
        self.transform=image_transforms(self.data_type,size,train=split=='train')
        self.bcl = bcl and split=='train'
        self.contrastive=image_transforms(self.data_type,size,train=True,bcl=True) if self.bcl else None
        if self.data_type=='cifar100lt':
            self.images,self.labels=_raw_cifar(self.root,'test' if split=='test' else 'train')

    def __len__(self):return len(self.samples)

    def __getitem__(self,i):
        item,label=self.samples[i]
        if self.data_type=='cifar100lt':
            img=Image.fromarray(self.images[int(item)],mode='RGB')
        else:
            with Image.open(self.root/item) as original: img=original.convert('RGB')
        if self.bcl:
            result=(self.transform(img),self.contrastive(img),self.contrastive(img))
        else:
            result=self.transform(img)
        return result,int(label),str(item)


def make_loader(manifest, split, size=224, batch_size=16, workers=0, seed=42,
                bcl=False, sampler=None):
    if manifest['dataset']=='cifar100lt' and size != 224:
        # Non-ViT CIFAR input sizes are allowed; this is a reminder only.
        pass
    ds=ImageDataset(manifest,split,size,bcl)
    kwargs=dict(batch_size=batch_size,num_workers=workers,pin_memory=torch.cuda.is_available(),
                persistent_workers=workers>0)
    return DataLoader(ds,shuffle=(split=='train' and sampler is None),sampler=sampler,
                      generator=torch.Generator().manual_seed(seed),**kwargs)
