import unittest
import torch
from rafa.model import RarityAwareFeatureAdapter
from rafa.metrics import shot_groups,compute_metrics


class AdapterTests(unittest.TestCase):
    def test_zero_init_identity_and_gradient(self):
        m=RarityAwareFeatureAdapter(12,[100,20,2],rank=4)
        z=torch.randn(5,12)
        y,aux=m(z,return_aux=True)
        self.assertTrue(torch.allclose(y,z,atol=1e-7))
        self.assertEqual(aux['probabilities'].shape,(5,3))
        self.assertTrue(bool(((aux['gate']>0)&(aux['gate']<1)).all()))
        loss=y.square().mean()+.1*m.auxiliary_loss(aux['router_logits'],torch.tensor([0,1,2,0,1]))
        loss.backward()
        self.assertGreater(float(m.up.weight.grad.abs().sum()),0)
        self.assertGreater(float(m.router.weight.grad.abs().sum()),0)

    def test_monotonic_gate(self):
        m=RarityAwareFeatureAdapter(8,[30,10,2])
        xs=torch.tensor([0.,.2,.5,.8,1.])
        g=torch.sigmoid(m.gate_bias+torch.nn.functional.softplus(m.gate_raw_slope)*xs)
        self.assertTrue(bool((g[1:]>=g[:-1]).all()))

    def test_no_labels_in_forward(self):
        m=RarityAwareFeatureAdapter(8,[20,6,1])
        self.assertEqual(tuple(m(torch.rand(2,8)).shape),(2,8))

    def test_metrics_and_groups(self):
        self.assertEqual(shot_groups([110,100,20,19,5],'threshold'),['Many','Medium','Medium','Few','Few'])
        groups=['Many','Medium','Few']
        result,_=compute_metrics([0,1,2,0,1,2],[0,1,1,0,2,2],3,groups)
        self.assertAlmostEqual(result['overall_acc'],4/6*100)
        self.assertAlmostEqual(result['many_acc'],100.)
        self.assertAlmostEqual(result['medium_acc'],50.)
        self.assertAlmostEqual(result['few_acc'],50.)

if __name__=='__main__':unittest.main()
