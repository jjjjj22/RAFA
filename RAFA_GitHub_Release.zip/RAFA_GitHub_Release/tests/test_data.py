import unittest
import tempfile
from pathlib import Path
from PIL import Image
from rafa.data import create_folder_manifest,load_manifest,training_counts,ImageDataset


class SplitTests(unittest.TestCase):
    def test_folder_splits_deterministic_and_nonleaky(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)/'images'
            for cls in ['c0','c1','c2']:
                (root/cls).mkdir(parents=True)
                for i in range(6):Image.new('RGB',(32,32),(i*12,20,30)).save(root/cls/f'{i}.png')
            obj=create_folder_manifest(root,Path(temp)/'manifest.json',seed=7)
            obj=load_manifest(Path(temp)/'manifest.json')
            self.assertEqual(len(obj['classes']),3)
            self.assertEqual(len(obj['train'])+len(obj['val'])+len(obj['test']),18)
            self.assertEqual(sum(training_counts(obj)),len(obj['train']))
            img,label,name=ImageDataset(obj,'test',size=64)[0]
            self.assertEqual(tuple(img.shape),(3,64,64))

if __name__=='__main__':unittest.main()
