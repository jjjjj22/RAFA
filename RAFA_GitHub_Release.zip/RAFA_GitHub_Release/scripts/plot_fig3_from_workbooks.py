"""RAFA Fig. 3: cross-dataset gain heatmaps and head-tail trade-off scatter.

Run directly in PyCharm or from a terminal:
    python rafa_fig3_visualization.py

Dependencies:
    pip install numpy pandas matplotlib openpyxl

Place these three workbooks either next to this file or in a sibling `upload/`:
    IF100-results.xlsx, DLCPD-Results.xlsx, PlantWild-Results.xlsx

Each output is written separately as PNG (600 dpi), PDF and editable SVG.
"""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm
from matplotlib.lines import Line2D
from matplotlib import font_manager


# -----------------------------------------------------------------------------
# 1. Editable settings
# -----------------------------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "upload" if (BASE_DIR / "upload").exists() else BASE_DIR
OUTPUT_DIR = BASE_DIR / "RAFA_Fig3"
OUTPUT_FORMATS = ("png", "pdf", "svg")
DPI = 600

# A shared diverging color range. Large gains are clipped in color only;
# ALL cell labels retain the exact percentage-point differences.
HEATMAP_COLOR_LIMIT_PP = 4.0
DRAW_SCATTER_ZOOM = True  # Set False to use one scatter panel only.

DATASETS = [
    ("CIFAR-100-LT (IF=100)", "IF100-results.xlsx", "#4B77A5"),
    ("DLCPD-25", "DLCPD-Results.xlsx", "#278B80"),
    ("PlantWild v2", "PlantWild-Results.xlsx", "#D28B4F"),
]

METHODS = ["ResNet18", "ViT", "CE", "BS", "BCL", "BBN", "RIDE", "DBM", "H2T"]
METHOD_LABELS = {
    "ResNet18": "ResNet-18", "ViT": "ViT", "CE": "CE",
    "BS": "Bal. Softmax", "BCL": "BCL", "BBN": "BBN",
    "RIDE": "RIDE", "DBM": "DBM", "H2T": "H2T",
}
METRICS = [
    ("many_acc", "Many"),
    ("medium_acc", "Medium"),
    ("few_acc", "Few"),
    ("macro_f1", "Macro-F1"),
    ("overall_acc", "All"),
]

# Corrected values provided after the original workbook was shared.
# For this one method, ALL seven corrected metrics are applied consistently.
PLANTWILD_RESNET18_CORRECTIONS = {
    "overall_acc": (0.682906, 0.699),
    "macro_f1": (0.601083, 0.628757),
    "macro_precision": (0.625491, 0.658099),
    "macro_recall": (0.594827, 0.623427),
    "many_acc": (0.823490, 0.808653),
    "medium_acc": (0.603200, 0.625597),
    "few_acc": (0.275926, 0.414815),
}


def configure_style():
    """Use Times New Roman on Windows; a close serif fallback for local preview."""
    installed = {f.name for f in font_manager.fontManager.ttflist}
    font = "Times New Roman" if "Times New Roman" in installed else "Liberation Serif"
    plt.rcParams.update({
        "font.family": font,
        "font.size": 10,
        "axes.titlesize": 12,
        "axes.labelsize": 11,
        "xtick.labelsize": 9,
        "ytick.labelsize": 9,
        "axes.edgecolor": "#475569",
        "axes.linewidth": 0.8,
        "text.color": "#243340",
        "axes.labelcolor": "#243340",
        "xtick.color": "#425366",
        "ytick.color": "#425366",
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",  # Preserve SVG text as editable font objects.
        "savefig.facecolor": "white",
    })
    print(f"Figure font: {font}")


def read_results(filename):
    """Parse one Excel workbook into method -> metric -> (baseline, RAFA)."""
    path = DATA_DIR / filename
    if not path.is_file():
        raise FileNotFoundError(
            f"Missing input: {path}\n"
            "Put all three Excel files next to this script or under its upload/ folder."
        )

    table = pd.read_excel(path, sheet_name=0, header=None)
    data = {}
    current_method = None
    for _, row in table.iterrows():
        key = str(row.iloc[0]).strip() if pd.notna(row.iloc[0]) else ""
        if key in METHODS:
            current_method = key
            if key in data:
                raise ValueError(f"Duplicate method block '{key}' in {path.name}")
            data[key] = {}
            continue

        if key in {"overall_acc", "macro_f1", "macro_precision", "macro_recall",
                   "many_acc", "medium_acc", "few_acc"} and current_method:
            try:
                baseline = float(row.iloc[1])
                with_rafa = float(row.iloc[2])
            except (TypeError, ValueError) as exc:
                raise ValueError(f"Invalid {current_method}/{key} in {path.name}") from exc
            if not (0 <= baseline <= 1 and 0 <= with_rafa <= 1):
                raise ValueError(f"Metric outside [0, 1]: {current_method}/{key}")
            data[current_method][key] = (baseline, with_rafa)

    if filename == "PlantWild-Results.xlsx":
        data["ResNet18"].update(PLANTWILD_RESNET18_CORRECTIONS)

    for method in METHODS:
        if method not in data:
            raise ValueError(f"Method '{method}' not found in {path.name}")
        for metric, _ in METRICS:
            if metric not in data[method]:
                raise ValueError(f"Metric '{metric}' missing for {method} in {path.name}")

    return data


def gain_pp(results, method, metric):
    baseline, with_rafa = results[method][metric]
    return (with_rafa - baseline) * 100.0


def save_figure(fig, stem):
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    for ext in OUTPUT_FORMATS:
        path = OUTPUT_DIR / f"{stem}.{ext}"
        fig.savefig(path, dpi=DPI, bbox_inches="tight", pad_inches=0.12)
        print(f"Saved: {path}")


def plot_gain_heatmaps(all_data):
    """Three side-by-side gain matrices, one per dataset, sharing one colorbar."""
    nrows, ncols = len(METHODS), len(METRICS)
    fig, axes = plt.subplots(1, 3, figsize=(17.5, 5.15), sharey=True)
    cmap = LinearSegmentedColormap.from_list(
        "rafa_diverging", ["#B95C5D", "#F8F7F3", "#117B74"], N=256
    )
    cmap.set_under("#B95C5D")
    cmap.set_over("#117B74")
    norm = TwoSlopeNorm(
        vmin=-HEATMAP_COLOR_LIMIT_PP,
        vcenter=0.0,
        vmax=HEATMAP_COLOR_LIMIT_PP,
    )

    for i, ((dataset, _, _), ax) in enumerate(zip(DATASETS, axes)):
        values = np.array([
            [gain_pp(all_data[dataset], method, metric) for metric, _ in METRICS]
            for method in METHODS
        ])
        im = ax.imshow(values, cmap=cmap, norm=norm, interpolation="nearest", aspect="auto")

        ax.set_title(f"({chr(97+i)}) {dataset}", fontweight="bold", pad=12)
        ax.set_xticks(np.arange(ncols), [label for _, label in METRICS])
        ax.set_yticks(np.arange(nrows), [METHOD_LABELS[m] for m in METHODS])
        ax.tick_params(axis="both", length=0, pad=7)
        ax.tick_params(axis="y", labelleft=(i == 0))

        # Fine white gridlines and a gap between backbone tests and LT methods.
        ax.set_xticks(np.arange(-0.5, ncols, 1), minor=True)
        ax.set_yticks(np.arange(-0.5, nrows, 1), minor=True)
        ax.grid(which="minor", color="white", linewidth=1.5)
        ax.tick_params(which="minor", bottom=False, left=False)
        ax.axhline(1.5, color="#45566A", linewidth=1.8)

        for r in range(nrows):
            for c in range(ncols):
                value = values[r, c]
                # Large magnitude cells have dark colored backgrounds.
                label_color = "white" if abs(value) >= 2.6 else "#253643"
                ax.text(
                    c, r, f"{value:+.2f}", ha="center", va="center",
                    color=label_color, fontsize=9.0,
                    fontweight="bold" if c == 2 else "normal",
                )

        for spine in ax.spines.values():
            spine.set_visible(False)

    fig.subplots_adjust(left=0.105, right=0.99, top=0.90, bottom=0.22, wspace=0.13)
    colorbar_ax = fig.add_axes([0.32, 0.095, 0.39, 0.024])
    cb = fig.colorbar(im, cax=colorbar_ax, orientation="horizontal", extend="both")
    cb.set_ticks([-4, -2, 0, 2, 4])
    cb.set_ticklabels(["−4", "−2", "0", "+2", "+4"])
    cb.ax.tick_params(length=0, labelsize=9, pad=4)
    cb.outline.set_visible(False)
    cb.set_label("RAFA gain over baseline (percentage points)", labelpad=5, fontsize=10)
    # The palette saturates beyond the displayed limits, while annotations
    # keep the exact values; explain this in the manuscript figure caption.

    save_figure(fig, "Fig3a_RAFA_gain_heatmaps")
    plt.close(fig)


def plot_head_tail_scatter(all_data):
    """Head-tail trade-off: x=Many gain, y=Few gain, including an optional zoom."""
    fig, axes = plt.subplots(
        1, 2 if DRAW_SCATTER_ZOOM else 1,
        figsize=(11.8, 5.35) if DRAW_SCATTER_ZOOM else (7.7, 5.35),
    )
    if not isinstance(axes, np.ndarray):
        axes = np.array([axes])

    # Filled circles: LT methods; hollow diamonds: backbone generalization.
    for ax_i, ax in enumerate(axes):
        ax.set_facecolor("#FCFDFC")
        ax.axhline(0, color="#94A3B8", linestyle="--", linewidth=1.0, zorder=1)
        ax.axvline(0, color="#94A3B8", linestyle="--", linewidth=1.0, zorder=1)
        ax.grid(True, linestyle=":", color="#D9E1E6", linewidth=0.8)
        ax.set_axisbelow(True)

        for dataset, _, color in DATASETS:
            results = all_data[dataset]
            for method in METHODS:
                x = gain_pp(results, method, "many_acc")
                y = gain_pp(results, method, "few_acc")
                if method in {"ResNet18", "ViT"}:
                    ax.scatter(
                        x, y, s=68, marker="D", facecolor="white", edgecolor=color,
                        linewidth=1.8, zorder=5,
                    )
                else:
                    ax.scatter(
                        x, y, s=62, marker="o", facecolor=color, edgecolor="white",
                        linewidth=0.8, alpha=0.88, zorder=4,
                    )

        if ax_i == 0:
            ax.set_xlim(-3.65, 8.65)
            ax.set_ylim(-1.0, 21.0)
            ax.set_title("(a) All datasets", fontweight="bold", pad=13)
            ax.set_ylabel("Few-shot accuracy gain (pp)")
            ax.annotate(
                "PlantWild / BCL", xy=(0, gain_pp(all_data["PlantWild v2"], "BCL", "few_acc")),
                xytext=(8, -9), textcoords="offset points", fontsize=8, color="#86592E",
            )
            ax.annotate(
                "PlantWild / ResNet-18", xy=(gain_pp(all_data["PlantWild v2"], "ResNet18", "many_acc"),
                                              gain_pp(all_data["PlantWild v2"], "ResNet18", "few_acc")),
                xytext=(-6, -18), textcoords="offset points", ha="left", fontsize=8,
                color="#86592E",
            )
        else:
            ax.set_xlim(-2.35, 2.65)
            ax.set_ylim(-0.6, 6.5)
            ax.set_title("(b) Zoom: smaller gains", fontweight="bold", pad=13)
            ax.set_ylabel("Few-shot accuracy gain (pp)")

        ax.set_xlabel("Many-shot accuracy gain (pp)")
        ax.tick_params(direction="out", length=3)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)

    dataset_legend = [
        Line2D([0], [0], marker="o", linestyle="None", markersize=7,
               markerfacecolor=color, markeredgecolor="white", label=dataset)
        for dataset, _, color in DATASETS
    ]
    type_legend = [
        Line2D([0], [0], marker="o", linestyle="None", markersize=7,
               markerfacecolor="#64748B", markeredgecolor="white", label="LT methods"),
        Line2D([0], [0], marker="D", linestyle="None", markersize=6,
               markerfacecolor="white", markeredgecolor="#64748B", label="Backbones"),
    ]
    fig.subplots_adjust(left=0.09, right=0.985, top=0.85, bottom=0.23,
                        wspace=0.26 if DRAW_SCATTER_ZOOM else 0)
    fig.legend(
        handles=dataset_legend + type_legend, loc="lower center",
        bbox_to_anchor=(0.5, 0.035), ncol=5, frameon=False,
        columnspacing=1.8, handletextpad=0.4, fontsize=9,
    )
    save_figure(fig, "Fig3b_RAFA_head_tail_scatter")
    plt.close(fig)


def main():
    configure_style()
    all_data = {dataset: read_results(filename) for dataset, filename, _ in DATASETS}
    print("\nSource validation: all three workbooks contain 9 baseline/+RAFA pairs.")
    print("PlantWild/ResNet-18 is overridden using the corrected values you provided.")
    print("\nSanity checks (percentage-point differences):")
    for name in ["CIFAR-100-LT (IF=100)", "PlantWild v2"]:
        results = all_data[name]
        for metric in ["many_acc", "medium_acc", "few_acc", "overall_acc", "macro_f1"]:
            print(f"  {name:24s} ResNet-18 {metric:12s}: "
                  f"{gain_pp(results, 'ResNet18', metric):+7.3f} pp")
    plot_gain_heatmaps(all_data)
    plot_head_tail_scatter(all_data)


if __name__ == "__main__":
    main()
