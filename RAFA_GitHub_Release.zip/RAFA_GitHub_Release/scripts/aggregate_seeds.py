"""Mean ± SAMPLE SD from actual seed runs. Never synthesizes SD values."""
import argparse
import csv
import json
from pathlib import Path
import statistics


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--runs',default='runs/comparison')
    p.add_argument('--output',default='runs/mean_sd.csv')
    p.add_argument('--min-seeds',type=int,default=3)
    args=p.parse_args()
    items={}
    for path in Path(args.runs).rglob('test_results/metrics.json'):
        with path.open() as f:d=json.load(f)
        key=(d['method'],d['backbone'],d['variant'])
        items.setdefault(key,{})[d['seed']]=d
    rows=[]
    for (method,backbone,variant),seeds in sorted(items.items()):
        if len(seeds)<args.min_seeds: raise ValueError(f'{method}/{backbone}/{variant}: only {len(seeds)} seeds; need {args.min_seeds}')
        row={'method':method,'backbone':backbone,'variant':variant,'seeds':','.join(map(str,sorted(seeds))),'K':len(seeds)}
        for metric in ('overall_acc','macro_f1','many_acc','medium_acc','few_acc'):
            values=[d[metric] for d in seeds.values() if d.get(metric) is not None]
            if len(values)>=2:
                row[metric+'_mean']=round(statistics.mean(values),4)
                row[metric+'_sd']=round(statistics.stdev(values),4)
            else:
                row[metric+'_mean']=row[metric+'_sd']=''
        rows.append(row)
    dest=Path(args.output);dest.parent.mkdir(parents=True,exist_ok=True)
    if rows:
        with dest.open('w',newline='',encoding='utf-8') as f:
            w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
    print(f'Saved {len(rows)} groups -> {dest}')

if __name__=='__main__':main()
