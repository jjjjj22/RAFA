"""Create and freeze a split manifest once, then reuse for every experiment."""
import argparse
from rafa.data import create_cifar_manifest,create_folder_manifest,training_counts
from rafa.metrics import shot_groups
from collections import Counter


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--dataset',choices=('cifar100lt','folder'),required=True)
    p.add_argument('--root',required=True)
    p.add_argument('--output',required=True)
    p.add_argument('--seed',type=int,default=42)
    p.add_argument('--imb-factor',type=float,default=100.)
    p.add_argument('--val-ratio',type=float,default=.1)
    p.add_argument('--train-ratio',type=float,default=.72)
    p.add_argument('--group-method',choices=('auto','threshold','knee','tertile'),default='auto')
    a=p.parse_args()
    if a.dataset=='cifar100lt':
        obj=create_cifar_manifest(a.root,a.output,a.imb_factor,a.val_ratio,a.seed)
    else:
        obj=create_folder_manifest(a.root,a.output,a.train_ratio,a.val_ratio,a.seed)
    g=shot_groups(training_counts(obj),a.group_method)
    print('Saved',a.output,'| classes',len(obj['classes']), '| partitions',
          *(f'{s}={len(obj[s])}' for s in ('train','val','test')))
    print('Shot groups:',dict(Counter(g)))

if __name__=='__main__': main()
