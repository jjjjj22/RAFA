Store experiment notebooks here after checking that they do not contain private dataset paths, credentials, embedded raw data or unverified result tables.
