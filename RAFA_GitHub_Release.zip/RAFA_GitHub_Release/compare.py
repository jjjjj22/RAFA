"""Train Baseline -> Baseline+RAFA on the exact same split and random seed."""
import argparse
import subprocess
import sys
from pathlib import Path
from rafa.utils import json_save, csv_save
import json


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--manifest',required=True)
    p.add_argument('--methods',default='ce,bs,bcl',help='Comma separated: ce,bs,bcl,bbn,ride,dbm,h2t')
    p.add_argument('--backbones',default='resnet18')
    p.add_argument('--seeds',default='42',help='Comma separated seeds, e.g. 42,43,44')
    p.add_argument('--output',default='runs/comparison')
    a,other=p.parse_known_args()
    root=Path(a.output);root.mkdir(parents=True,exist_ok=True)
    records=[]
    for name in a.methods.split(','):
        for backbone in a.backbones.split(','):
            for seed in a.seeds.split(','):
                pair={}
                for variant in ('baseline','rafa'):
                    out=root/name/backbone/f'seed_{seed}'/variant
                    command=[sys.executable,str(Path(__file__).parent/'train.py'),
                             '--manifest',a.manifest,'--method',name,
                             '--backbone',backbone,'--variant',variant,
                             '--seed',seed,'--output',str(out),*other]
                    print('RUN:', ' '.join(command),flush=True)
                    subprocess.run(command,check=True)
                    with (out/'test_results'/'metrics.json').open() as f: pair[variant]=json.load(f)
                row={'method':name,'backbone':backbone,'seed':seed}
                for metric in ('overall_acc','macro_f1','many_acc','medium_acc','few_acc'):
                    row[metric+'_baseline']=pair['baseline'].get(metric)
                    row[metric+'_rafa']=pair['rafa'].get(metric)
                    a0=pair['baseline'].get(metric)
                    a1=pair['rafa'].get(metric)
                    row[metric+'_delta_pp']=round(a1-a0,5) if a0 is not None and a1 is not None else None
                records.append(row)
                csv_save(root/'comparison.csv',records)
    json_save(root/'comparison.json',records)
    print('Saved',root/'comparison.csv')

if __name__=='__main__':main()
